import Foundation

extension ConsoleTools {
    var deviceState: String {
        app.deviceState
    }
}
