enum InsulinType: String, Codable {
    case bolus,
         basal
}
