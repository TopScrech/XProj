enum Tab: String {
    case monitor,
         online,
         console,
         settings,
         data,
         plan,
         healthKit,
         debug
}
